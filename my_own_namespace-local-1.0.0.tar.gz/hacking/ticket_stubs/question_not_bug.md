Hi!

Thanks very much for your interest in Ansible.  It means a lot to us.

This appears to be a user question, and we'd like to direct these kinds of things to either the mailing list or the IRC channel.

   * IRC: #ansible on [irc.libera.chat](https://libera.chat/)
   * mailing list: https://groups.google.com/forum/#!forum/ansible-project

See  this page for a complete and up to date list of communication channels and their purposes:

   * https://docs.ansible.com/ansible/latest/community/communication.html

Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
If don't you think this particular issue is resolved, you should still stop by there first, we'd appreciate it.
This allows us to keep the issue tracker for bugs, pull requests, RFEs and the like.

Thank you once again and we look forward to seeing you on the list or IRC.  Thanks!

