##### SUMMARY
%(component)s contains call to Display.deprecated or AnsibleModule.deprecate and is scheduled for removal

```
%(line)s
```

##### ISSUE TYPE
 - Bug Report

##### COMPONENT NAME
```
%(path)s
```

##### ANSIBLE VERSION
```
%(version)s
```

##### CONFIGURATION
N/A

##### OS / ENVIRONMENT
N/A

##### STEPS TO REPRODUCE
N/A

##### EXPECTED RESULTS
N/A

##### ACTUAL RESULTS
N/A
