# IMPORTANT!

Files under this directory are not actual plugins and modules used by Ansible
and as such should **not be modified**. They are used for testing purposes
only (and are temporary).

In almost every case, pull requests affecting files under this directory
will be closed.

**You are likely looking for something under
https://github.com/ansible-collections/ instead.**
